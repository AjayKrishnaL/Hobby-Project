﻿using LinqToExcel;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Http = System.Web.Http;
using FileUpload.Models;
namespace FileUpload.Controllers
{
    
    public class FileUploadController : Http.ApiController
    {
        // GET: FileUpload
        string extension;
        List<TestData> TestData = new List<TestData>();
        [Http.HttpPost()]
        public string UploadFiles()
        {
            int iUploadedCnt = 0;

            // DEFINE THE PATH WHERE WE WANT TO SAVE THE FILES.
            string sPath = "";
            sPath = System.Web.Hosting.HostingEnvironment.MapPath("~/locker/");

            System.Web.HttpFileCollection hfc = System.Web.HttpContext.Current.Request.Files;

            // CHECK THE FILE COUNT.
            for (int iCnt = 0; iCnt <= hfc.Count - 1; iCnt++)
            {
                System.Web.HttpPostedFile hpf = hfc[iCnt];
                
                if (hpf.ContentLength > 0)
                {
                    // CHECK IF THE SELECTED FILE(S) ALREADY EXISTS IN FOLDER. (AVOID DUPLICATE)
                    if (!File.Exists(sPath + Path.GetFileName(hpf.FileName)))
                    {
                        extension = Path.GetExtension(hpf.FileName);
                        if (extension.Equals(".xls") || extension.Equals(".xlsx"))
                        {
                            // SAVE THE FILES IN THE FOLDER.
                            hpf.SaveAs(sPath + Path.GetFileName(hpf.FileName));
                            iUploadedCnt = iUploadedCnt + 1;
                            string pathToExcelFile = sPath+ hpf.FileName;

                            string sheetName = "Sheet1";

                            var excelFile = new ExcelQueryFactory(pathToExcelFile);
                            var getData = from a in excelFile.Worksheet(sheetName) select a;

                            int count=0;
                            foreach (var a in getData)
                            {
                                TestData.Add(new TestData() { Id = int.Parse(a["Id"]),FirstName=a["FirstName"],LastName= a["LastName"],Age=int.Parse(a["Age"]) });
                                count = count + 1;
                            }
                            return count + " is the total values added";
                        }
                        else
                        {
                            return "Please insert only excel file";
                        }
                    }
                }
            }

            // RETURN A MESSAGE (OPTIONAL).
            if (iUploadedCnt > 0)
            {
                return iUploadedCnt + " Files Uploaded Successfully";
            }
            else
            {
                return "Upload Failed";
            }
        }
    }
}
