﻿//made by vipul mirajkar thevipulm.appspot.com
$(document).ready(function () {
    $(".firstnamevalidate").hide();
    $(".lastnamevalidate").hide();
    $(".pickupvalidate").hide();
    $(".dropvalidate").hide();
    $(".starttimevalidate").hide();
    $(".endtimevalidate").hide();
    $(".startdatevalidate").hide();
    $(".enddatevalidate").hide();
    $("#TermsCheck").prop("checked", false);
    $('#register').attr('disabled', 'disabled');
    $('#start_time').timepicker({
        hourGrid: 4,
        minuteGrid: 10,
    });
    $('#end_time').timepicker({
        hourGrid: 4,
        minuteGrid: 10,
    });
    $('#start_date').datepicker({
        showOtherMonths: true,
        selectOtherMonths: true
    });
    $('#end_date').datepicker({
        showOtherMonths: true,
        selectOtherMonths: true
    });
    $('#TermsCheck').click(function () {
        if ($(this).is(':checked')) {
            $('#register').removeAttr('disabled');
        }
        else if ($(this).not(':checked')) {
            $('#register').attr('disabled', 'disabled');
        }
    });
    var firstName = $("#first_name").val();
    var lastName = $("#last_name").val();
    var pickupLocation = $("#Pickup_Location").val();
    var dropLocation = $("#Drop_Location").val();
    var startTime = $("#start_time").val();
    var endTime = $("#end_time").val();
    var startDate = $("#start_date").val();
    var endDate = $("#end_date").val();

    // jQuery extend functions for popup
    (function ($) {
        $.fn.openPopup = function (settings) {
            var elem = $(this);
            // Establish our default settings
            var settings = $.extend({
                anim: 'fade'
            }, settings);
            elem.show();
            elem.find('.popup-content').addClass(settings.anim + 'In');
        }

        $.fn.closePopup = function (settings) {
            var elem = $(this);
            // Establish our default settings
            var settings = $.extend({
                anim: 'fade'
            }, settings);
            elem.find('.popup-content').removeClass(settings.anim + 'In').addClass(settings.anim + 'Out');

            setTimeout(function () {
                elem.hide();
                elem.find('.popup-content').removeClass(settings.anim + 'Out')
            }, 500);
        }

    }(jQuery));

    // Click functions for popup
    $('.open-popup').click(function () {
        $('#' + $(this).data('id')).openPopup({
            anim: (!$(this).attr('data-animation') || $(this).data('animation') == null) ? 'fade' : $(this).data('animation')
        });
    });
    $('.close-popup').click(function () {
        $('#' + $(this).data('id')).closePopup({
            anim: (!$(this).attr('data-animation') || $(this).data('animation') == null) ? 'fade' : $(this).data('animation')
        });
    });

    // To open/close the popup at any functions call the below
    // $('#popup_default').openPopup();
    // $('#popup_default').closePopup();
    $("#register").click(function () {
        if (firstName.length === 0) {
            $(".firstnamevalidate").show();
        }
        if (lastName.length === 0) {
            $(".lastnamevalidate").show();

        }
        if (pickupLocation.length === 0) {
            $(".pickupvalidate").show();

        }
        if (dropLocation.length === 0) {
            $(".dropvalidate").show();

        }
        if (startTime.length === 0) {
            $(".starttimevalidate").show();

        }
        if (endTime.length === 0) {
            $(".endtimevalidate").show();

        }
        if (startDate.length === 0) {
            $(".startdatevalidate").show();

        }
        if (endDate.length === 0) {
            $(".enddatevalidate").show();

        }
        if (firstName.length === 0 || lastName.length === 0 || pickupLocation.length === 0 || dropLocation.length === 0 || startTime.length === 0 || endTime.length === 0 || startDate.length === 0 || endDate.length === 0) {
            $("#shake").effect("shake");
        }
    });

});

var TxtType = function (el, toRotate, period) {
    this.toRotate = toRotate;
    this.el = el;
    this.loopNum = 0;
    this.period = parseInt(period, 10) || 2000;
    this.txt = '';
    this.tick();
    this.isDeleting = false;
};

TxtType.prototype.tick = function () {
    var i = this.loopNum % this.toRotate.length;
    var fullTxt = this.toRotate[i];

    if (this.isDeleting) {
        this.txt = fullTxt.substring(0, this.txt.length - 1);
    } else {
        this.txt = fullTxt.substring(0, this.txt.length + 1);
    }

    this.el.innerHTML = '<span class="wrap1">' + this.txt + '</span>';

    var that = this;
    var delta = 200 - Math.random() * 100;

    if (this.isDeleting) { delta /= 2; }

    if (!this.isDeleting && this.txt === fullTxt) {
        delta = this.period;
        this.isDeleting = true;
    } else if (this.isDeleting && this.txt === '') {
        this.isDeleting = false;
        this.loopNum++;
        delta = 500;
    }

    setTimeout(function () {
        that.tick();
    }, delta);
};

window.onload = function () {
    var elements = document.getElementsByClassName('typewrite');
    for (var i = 0; i < elements.length; i++) {
        var toRotate = elements[i].getAttribute('data-type');
        var period = elements[i].getAttribute('data-period');
        if (toRotate) {
            new TxtType(elements[i], JSON.parse(toRotate), period);
        }
    }
    // INJECT CSS
    var css = document.createElement("style");
    css.type = "text/css";
    css.innerHTML = ".typewrite > .wrap1 { border-right: 0.08em solid #fff}";
    document.body.appendChild(css);

};

