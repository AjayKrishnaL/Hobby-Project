Create a  new folder named 'MVCDreamProject'. 
inside the folder extract files from 'MVCDreamProject with solution'
Then extract Packages